﻿// Fig. 3.1: Welcome1.cs
// Text-displaying app.
using System;
 
class Welcome1
{
   // Main method begins execution of C# app
   static void Main()
   {
      Console.WriteLine("Welcome to C# Programming!");                   
   } // end Main
} // end class Welcome1
